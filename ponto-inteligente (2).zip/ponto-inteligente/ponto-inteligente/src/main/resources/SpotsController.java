
package com.pontointeligente;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpotsController {

    @GetMapping("/api/v1/spots")
    public String listarSpots() {
        return "API Ponto Inteligente funcionando!";
    }
}
