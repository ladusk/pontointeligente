package com.pontointeligente.ponto_inteligente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PontoInteligenteApplicationTests {

	@Test
	void contextLoads() {
	}

}
